<?php include('../../php/head.php'); ?>
    <!-- Page Content -->
    <div class="container test min-width mar-top mar-bot">

        <div class="row center">
            <div class="col-lg-12 text-center">
                <h1>Homepage</h1>
                <p class="lead">Choose a use case in the main menu</p>
                <ul class="list-unstyled">
                    <li>High Fidelity Design v.1.0.0</li>
                    <li>Vélibgroep10</li>
                </ul>
            </div>
        </div>
        <!-- /.row -->

    </div>
    <!-- /.container -->


<?php include('../../php/foot.php') ?>
