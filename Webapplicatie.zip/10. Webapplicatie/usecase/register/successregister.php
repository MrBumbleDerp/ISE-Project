<?php include('../../php/head.php'); ?>

    <!-- Page Content -->
    <div class="container full-page min-width test">

        <div class="row">
            <div class="col-lg-12 text-center">
                <h1>You have successfully subscribed to Vélib' Passion</h1>
                <p class="lead">Click the button below to go back to the main menu</p>
            </div>
        </div>

        <div class="row center">
          <a href="../home/index.php"><button type="button" class="btn btn-primary mar-top mar-bot2 ">Go Back</button></a>
      </div>

      <?php include('../../php/foot.php') ?>
