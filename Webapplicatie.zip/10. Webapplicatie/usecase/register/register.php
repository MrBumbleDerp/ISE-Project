<?php include('../../php/head.php'); ?>
    <!-- Page Content -->
    <div class="container full-page test pad-bot min-width">

        <div class="row">
            <div class="col-lg-12 text-center">
                <h1>Register</h1>
                <p class="lead">Choose a subscription</p>
            </div>
        </div>
        <div class="row center mar-bot">
          <div class="btn-group" role="group" aria-label="...">
            <a href="passion.php"><button type="button" class="btn btn-primary btn-lg">Vélib' Classique</button></a>
            <a href="passion.php"><button type="button" class="btn btn-primary btn-lg">Vélib' Passion</button></a>
          </div>
      </div>

      <div class="row center">
        <div class="btn-group" role="group" aria-label="...">
          <button type="button" class="btn btn-default btn-lg">1-day ticket</button>
          <button type="button" class="btn btn-default btn-lg">7-day ticket</button>
        </div>
    </div>
    </div>

<?php include('../../php/foot.php'); ?>
