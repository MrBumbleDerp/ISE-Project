<?php include('../../php/head.php'); ?>
    <!-- Page Content -->
    <div class="container full-page">

        <div class="row">
            <div class="col-lg-12 text-center">
                <h1>Rent a bike</h1>
                <p class="lead">Please enter a bikenumber below</p>
            </div>
        </div>
        <div class="alert alert-danger center min-width content-center" role="alert">Uh oh! That bikenumber is not available! Please enter another bikenumber.</div>

        <div class="row center">
          <input class="form-control input-lg min-width center content-center mar-bot2" type="text">
          <div class="btn-group" role="group" aria-label="...">
            <a href="rentsuccess.html"><button type="button" class="btn btn-default btn-lg">Unlock</button></a>
          </div>
      </div>
      </div>
    </div>
    <?php include('../../php/foot.php') ?>
