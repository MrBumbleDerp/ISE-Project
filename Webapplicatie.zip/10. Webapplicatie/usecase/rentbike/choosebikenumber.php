<?php include('../../php/head.php'); ?>
    <!-- Page Content -->
    <div class="container full-page test min-width">

        <div class="row">
            <div class="col-lg-12 text-center">
                <h1>Rent a bike</h1>
                <p class="lead">Please enter a bikenumber below</p>
            </div>
        </div>
        <div class="row center mar-bot2">
          <input class="form-control input-lg min-width center content-center mar-bot2" type="text">
          <div class="btn-group" role="group" aria-label="...">
            <a href="rentsuccess.php"><button type="button" class="btn btn-primary btn-lg">Unlock</button></a>
          </div>
      </div>
    </div>
<?php include('../../php/foot.php') ?>
