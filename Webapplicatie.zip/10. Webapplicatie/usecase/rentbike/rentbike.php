<?php include('../../php/head.php'); ?>
    <!-- Page Content -->
    <div class="container full-page test min-width">

        <div class="row">
            <div class="col-lg-12 text-center">
                <h1>Rent a bike</h1>
                <p class="lead">Please select a bike</p>
            </div>
        </div>
        <div class="row center mar-bot2">
          <div class="btn-group" role="group" aria-label="...">
            <a href="choosebikenumber.php"><button type="button" class="btn btn-primary btn-lg">Rent a bike</button></a>
            <a href="#"><button type="button" class="btn btn-info btn-lg">Balance</button></a>
          </div>
      </div>
    </div>
<?php include('../../php/foot.php') ?>
