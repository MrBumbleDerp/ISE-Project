<?php include('../../php/head.php'); ?>
    <!-- Page Content -->
    <div class="container full-page test min-width">

        <div class="row">
            <div class="col-lg-12 text-center">
                <h1>Thank you</h1>
                <p class="lead">You have succesfully returned your bike.</p>
            </div>
        </div>
        <div class="row center">
          <div class="btn-group" role="group" aria-label="...">
            <a href="../home/index.php"><button type="button" class="btn btn-primary btn-lg mar-bot2">Print receipt</button></a>
          </div>
      </div>
    </div>
    <?php include('../../php/foot.php') ?>
